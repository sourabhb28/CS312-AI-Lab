***************ASSIGNMENT 5 ****************
- Extract the files in a Linux Environment
- Use """bash run.sh """ to run the MyBot.cpp against RandomBot.cpp
- For minimax against alphabeta, use """bash printTree.sh"""