/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include <chrono>
#include "Othello.h"
#include "OthelloPlayer.h"
#include "OthelloBoard.h"

using namespace std;
using namespace Desdemona;

#define INT_MIN -2147483648
#define INT_MAX +2147483647

// record start time
auto start = chrono::steady_clock::now();

class MyBot : public OthelloPlayer // class MyBot inherits properties of class OthelloPlayer
{
public:
    MyBot(Turn turn); // constructor, is an empty function here
    // constructor = function called at the time of creation of an object
    // constructor of base class is called before that of sub class

    // virtual functions: may be pre-defined for the base classes, but is re-defined 
    // to avoid clashing. Kind of like local/global variable
    virtual Move play(const OthelloBoard &board);
    virtual int Minimax(OthelloBoard &board, Turn turn, int depth, Move move, int Min, int Max);
    virtual int heuristic(OthelloBoard &board, int mode);
};

MyBot::MyBot(Turn turn) : OthelloPlayer(turn) {}
// parameterized constructor, sends turn as call by value for the parent constructor as well

int MyBot::heuristic(OthelloBoard &board, int mode)
{
    // heuristic values of the squares
    // 16.16 -3.51 1.16 0.53
    // -3.51 -1.81 -0.06 -0.23
    // 1.16 -0.06  0.51  0.06
    // 0.53 -0.23 -0.06 -0.01
    
    // get number of moves possible at this point of time for both players
    int oppoPossibleMoves = board.getValidMoves(other(this->turn)).size();
    int myPossibleMoves = board.getValidMoves(this->turn).size();

    int diffenceMoves = myPossibleMoves - oppoPossibleMoves;

    // different heuristics
    switch (mode)
    {
    case 0: // position-based heuristic (Corner/Edge-captivity)
    {
        int myValue = 0;
        int oppValue = 0;

        // Weightages are according to the positions on the board here
        int a[] = {0, 0, 7, 7};
        int b[] = {0, 7, 0, 7};
        for (int i = 0; i < 4; ++i)
        {
            if (board.get(a[i], b[i]) == this->turn)
                myValue += 1616;
            else if (board.get(a[i], b[i]) == other(this->turn))
                oppValue += 1616;
        }

        int c[] = {2, 0, 7, 2, 0, 5, 5, 7};
        int d[] = {0, 2, 2, 7, 5, 0, 7, 5};
        for (int i = 0; i < 8; ++i)
        {
            if (board.get(c[i], d[i]) == this->turn)
                myValue += 116;
            else if (board.get(c[i], d[i]) == other(this->turn))
                oppValue += 116;
        }

        int e[] = {3, 0, 7, 3, 0, 4, 4, 7};
        int f[] = {0, 3, 3, 7, 4, 0, 7, 4};
        for (int i = 0; i < 8; ++i)
        {
            if (board.get(e[i], f[i]) == this->turn)
                myValue += 53;
            else if (board.get(e[i], f[i]) == other(this->turn))
                oppValue += 53;
        }

        int g[] = {2, 2, 5, 5};
        int h[] = {2, 5, 2, 5};
        for (int i = 0; i < 4; ++i)
        {
            if (board.get(g[i], h[i]) == this->turn)
                myValue += 51;
            else if (board.get(g[i], h[i]) == other(this->turn))
                oppValue += 51;
        }

        int u[] = {3, 3, 4, 4};
        int j[] = {2, 5, 2, 5};
        for (int i = 0; i < 4; ++i)
        {
            if (board.get(u[i], j[i]) == this->turn)
                myValue += 7;
            else if (board.get(u[i], j[i]) == other(this->turn))
                oppValue += 7;
        }

        int k[] = {3, 3, 4, 4};
        int l[] = {3, 4, 3, 4};
        for (int i = 0; i < 4; ++i)
        {
            if (board.get(k[i], l[i]) == this->turn)
                myValue -= 1;
            else if (board.get(k[i], l[i]) == other(this->turn))
                oppValue -= 1;
        }

        int m[] = {2, 1, 6, 5, 1, 5, 6, 2, 2, 2, 5, 5};
        int n[] = {1, 2, 5, 6, 5, 1, 2, 6, 3, 4, 3, 4};
        for (int i = 0; i < 12; ++i)
        {
            if (board.get(m[i], n[i]) == this->turn)
                myValue -= 6;
            else if (board.get(m[i], n[i]) == other(this->turn))
                oppValue -= 6;
        }

        int o[] = {3, 1, 6, 4, 1, 4, 6, 3};
        int p[] = {1, 3, 4, 6, 4, 1, 3, 6};
        for (int i = 0; i < 8; ++i)
        {
            if (board.get(o[i], p[i]) == this->turn)
                myValue -= 23;
            else if (board.get(o[i], p[i]) == other(this->turn))
                oppValue -= 23;
        }

        int q[] = {1, 1, 6, 6};
        int r[] = {1, 6, 1, 6};
        for (int i = 0; i < 4; ++i)
        {
            if (board.get(q[i], r[i]) == this->turn)
                myValue -= 181;
            else if (board.get(q[i], r[i]) == other(this->turn))
                oppValue -= 181;
        }

        // the squares right next to the corners have a negative effect
        int ss[] = {1, 0, 7, 1, 0, 6, 6, 7};
        int tt[] = {0, 1, 1, 7, 6, 0, 7, 6};
        for (int i = 0; i < 8; ++i)
        {
            if (board.get(ss[i], tt[i]) == this->turn)
                myValue -= 351;
            else if (board.get(ss[i], tt[i]) == other(this->turn))
                oppValue -= 351;
        }

        return (myValue - oppValue);
    }
    case 1: // difference of moves; not a greaat heuristic
        return diffenceMoves;
    case 2: // difference of coins; not a good heuristic at all
    {
        if (this->turn == RED)
            return (board.getRedCount() - board.getBlackCount());
        else
            return (board.getBlackCount() - board.getRedCount());
    }
    default:
        return (board.getBlackCount() - board.getRedCount());
    }
}

Move MyBot::play(const OthelloBoard &board)
{
    // record start time of move
    start = chrono::steady_clock::now();

    // get list of moves using given function
    list<Move> moves = board.getValidMoves(turn);

    // assume best move is the first member of moves list, and best_so_far = INT_MIN
    Move best_move = *moves.begin();
    int best_so_far = INT_MIN;

    int depth = 1;
    // while (depth++) // While 2 seconds not over or full board explored
    // {
        // check each possible move in moves
        for (Move nextMove : moves)
        {
            // get the board
            OthelloBoard gBoard = OthelloBoard(board);

            // find heuristic value if nextMove is applied on gboard, using Minimax
            int hvalue = Minimax(gBoard, this->turn, depth, nextMove, INT_MIN, INT_MAX);

            // if this hvalue is better, then set it to best_Move and set its hvalue of best_so_far
            if (hvalue > best_so_far)
            {
                best_move = nextMove;
                best_so_far = hvalue;
            }

            // if time is up, return best one so far
            if (hvalue == INT_MIN)
                return best_move;
        }
    // }
    printf("Selecting : (%d, %d)\n", best_move.x, best_move.y);
    // OthelloBoard(board).print(this->turn);
    return best_move;
}

int MyBot::Minimax(OthelloBoard &board, Turn turn, int depth, Move move, int Min, int Max)
{
    if (chrono::duration_cast<chrono::milliseconds>(chrono::steady_clock::now() - start).count() > 1500)
        return INT_MIN;

    // get the board
    OthelloBoard gBoard = OthelloBoard(board);
    gBoard.makeMove(turn, move);
    list<Move> gameTree = gBoard.getValidMoves(other(turn));

    if (depth == 0)
        return heuristic(gBoard, 0);

    printf("Exploring: (%d,%d),\t Depth = %d,\t Num of children = %ld \n", move.x, move.y, depth, gameTree.size());

    int branchNodes = 0;
    for (Move child : gameTree)
    {
        OthelloBoard interBoard = OthelloBoard(board);
        interBoard.makeMove(turn, move);
        printf("Child %d = (%d,%d): HeuristicValue: %d\n", branchNodes, child.x, child.y, heuristic(interBoard, 1));
        branchNodes++;
    }

    int bestValue = (this->turn == turn) ? INT_MAX : INT_MIN;

    if (this->turn == turn)
    {
        for (Move move : gameTree)
        {
            bestValue = min(bestValue, Minimax(gBoard, other(turn), depth - 1, move, Min, Max));
            if (Min >= min(Max, bestValue))
                break;
        }
    }
    else
    {
        for (Move move : gameTree)
        {
            bestValue = max(bestValue, Minimax(gBoard, other(turn), depth - 1, move, Min, Max));
            if (Max <= max(bestValue, Min))
                break;
        }
    }
    return bestValue;
}

// The following lines are _very_ important to create a bot module for Desdemona
extern "C"
{
    OthelloPlayer *createBot(Turn turn)
    {
        return new MyBot(turn);
    }

    void destroyBot(OthelloPlayer *bot)
    {
        delete bot;
    }
}
