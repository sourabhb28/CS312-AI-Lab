cd bots/AlphaBetaBot
make clean
make all
cd ../..
./bin/Desdemona ./bots/AlphaBetaBot/bot.so ./bots/MiniMaxBot/bot.so