cd bots/MyBot
make clean
make all
cd ../..
./bin/Desdemona ./bots/MyBot/bot.so ./bots/RandomBot/RandomBot.so