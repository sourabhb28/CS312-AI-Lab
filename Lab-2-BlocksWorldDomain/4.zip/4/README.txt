- Program does not use command line arguments
- to change input file, change line 257 

- To change heuristic function in BFS, 
- change lines 223 and 251

- To change heuristic function in hill climbing, 
- change lines 183 and 201

- The input files for BFS are input1.txt and input3.txt
- The input files for HC are input2.txt and input4.txt