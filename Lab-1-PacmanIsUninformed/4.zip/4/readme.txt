### Directions to Run Code :

- Open 4.py in IDE (VSCode)

- Run the python file. And input format as below:
	   < Algorithm code > //0 for BFS, 1 for DFS, 2 for DFID
	   < Maze of m x n size >
  
- To terminate stdin , enter the following command 
	  Control + Z —> Windows
	  Control + D —> Macbook
    
- Output will be displayed in the following format:
	  No. of	states explored.
	  Path length.
	  < Solved maze indicating path >
