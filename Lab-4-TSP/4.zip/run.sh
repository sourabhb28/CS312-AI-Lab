#!/bin/bash

python3 4.py $1